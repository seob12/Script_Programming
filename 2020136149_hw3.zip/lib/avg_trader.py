from trader import Trader
from bitstamp_info import *
from datetime import *

class AvgTrader(Trader):
    def __init__(self, init_asset):
        super().__init__(init_asset=init_asset)

    def buy_or_sell(position_list):
        result = 0
        count = 0

        for i in position_list:
            calculated_delta = datetime.now().date() - date.fromisoformat(i['time'])
            if calculated_delta <= timedelta(days=20) and calculated_delta > timedelta(days=1):
                result += i['price']
                count += 1
        avg = result / count
        current_price = get_current_price()

        if current_price > avg:
            return 'sell'
        elif current_price < avg:
            return 'buy'
