import ccxt
from datetime import datetime


def get_current_price():
    bitstamp = ccxt.bitstamp()
    ticker = bitstamp.fetch_ticker('BTCUSD')
    return float(ticker['close'])


def get_price_list(time_frame):
    try:
        bitstamp = ccxt.bitstamp()
        price_list = []
        date = datetime.now().date()

        if bitstamp.has['fetchTicker']:
            ohlcvs = bitstamp.fetch_ohlcv('BTC/USD', time_frame)
            #print(ohlcvs)

            for ohlcv in ohlcvs:
                s = datetime.fromtimestamp(ohlcv[0] / 1000).strftime('%Y-%m-%d')  # 날짜
                o = ohlcv[1]
                h = ohlcv[2]
                l = ohlcv[3]
                c = ohlcv[4]  # 가격
                d = {'time': s, 'price': c}
                price_list.append(d)
                #print(price_list)
        return price_list

    except Exception as ex:
        print(ex)
        return None

#if __name__ == '__main__':
  # get_price_list('date')

