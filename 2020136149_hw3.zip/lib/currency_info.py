import requests
from bs4 import BeautifulSoup

url = 'https://www.kita.net/cmmrcInfo/ehgtGnrlzInfo/rltmEhgt.do'
response = requests.get(url, headers = {'User-Agent': 'Mozilla/5.0'})
response.raise_for_status()
soup = BeautifulSoup(response.text, 'lxml')

def get_currency():
    if response.status_code == 200:
        title = soup.select_one('#contents > div.boardArea > div.tableSt.st4.alc > table > tbody > tr:nth-child(1) > td:nth-child(2)')
        data = title.get_text()
        #print(data)
    else:
        print(response.status_code)

    return data

