import random
import copy
from difflib import SequenceMatcher
from itertools import combinations

GENERATION = 10000

def evaluate_rapper_group(rapper_group):
    score = 0

    comb_ = (combinations(rapper_group, 2))
    for rapper_group in comb_:
        rapper_a = rapper_group[0]
        rapper_b = rapper_group[1]
        score += SequenceMatcher(None, rapper_a['mbti'], rapper_b['mbti']).ratio()
    
    return score


def evaluate_rapper_total_list(rapper_total_list):
    score_total = 0
    score_total = map(evaluate_rapper_group, rapper_total_list)
    return sum(score_total)


def crossover(rapper_total_list):
    random.shuffle(rapper_total_list)
    rapper_group1 = rapper_total_list[0]
    rapper_group2 = rapper_total_list[1]
    division_point = random.randint(0, 3)
    rapper_list1 = rapper_group1[division_point:]
    rapper_list2 = rapper_group2[division_point:]
    rapper_group1[division_point:] = rapper_list2
    rapper_group2[division_point:] = rapper_list1


def mutation(rapper_total_list):
    if random.random() < 0.1:
        random.shuffle(rapper_total_list)
        rapper_group1 = rapper_total_list[0]
        rapper_group2 = rapper_total_list[1]
        mutation_point = random.randint(0, 3)
        target1_dict = rapper_group1[mutation_point]
        target2_dict = rapper_group2[mutation_point]
        rapper_group1[mutation_point] = target2_dict
        rapper_group2[mutation_point] = target1_dict


def print_total(rapper_total_list):
    for rapper_group in rapper_total_list:
        for rapper in rapper_group:
            print(rapper)
        print()


if __name__ == '__main__':

    rapper_total = [
        [{'name': '머드 더 스튜던트', 'mbti': 'INFP'},
         {'name': '디보', 'mbti': 'ENFJ'},
         {'name': '이센스', 'mbti': 'ENTP'},
         {'name': '오메가 사피엔', 'mbti': 'ENTP'}],

        [{'name': '릴 체리', 'mbti': 'INFP'},
         {'name': '애쉬 아일랜드', 'mbti': 'INFJ'},
         {'name': '그레이', 'mbti': 'ENFJ'},
         {'name': '신스', 'mbti': 'ENFP'}],

        [{'name': '우디 고차일드', 'mbti': 'ENFP'},
         {'name': '빅나티', 'mbti': 'INFP'},
         {'name': '레디', 'mbti': 'ISFJ'},
         {'name': '블루', 'mbti': 'ENFP'}],

        [{'name': '저스디스', 'mbti': 'INFJ'},
         {'name': '정상수', 'mbti': 'INFP'},
         {'name': '골드부다', 'mbti': 'ENTP'},
         {'name': '타블로', 'mbti': 'INFP'}],

        [{'name': '머쉬베놈', 'mbti': 'ENFP'},
         {'name': '그냥노창', 'mbti': 'INFP'},
         {'name': '미란이', 'mbti': 'INFP'},
         {'name': '염따', 'mbti': 'ENTP'}],

        [{'name': '원슈타인', 'mbti': 'INFP'},
         {'name': '하온', 'mbti': 'INTP'},
         {'name': '딥플로우', 'mbti': 'INFP'},
         {'name': '최엘비', 'mbti': 'INFP'}],

        [{'name': '안병웅', 'mbti': 'INTP'},
         {'name': '로꼬', 'mbti': 'INFJ'},
         {'name': 'PH-1', 'mbti': 'INFP'},
         {'name': '더콰이엇', 'mbti': 'INFP'}],

        [{'name': '나플라', 'mbti': 'ESTJ'},
         {'name': '진보', 'mbti': 'ENFP'},
         {'name': '빈지노', 'mbti': 'INFP'},
         {'name': '지코', 'mbti': 'ENTJ'}],

        [{'name': '비비', 'mbti': 'ENFP'},
         {'name': '이영지', 'mbti': 'ENTP'},
         {'name': '제네 더 질라', 'mbti': 'INFP'},
         {'name': '쿠기', 'mbti': 'ESFJ'}],

        [{'name': '루피', 'mbti': 'INFP'},
         {'name': '소코도모', 'mbti': 'INTP'},
         {'name': '김농밀', 'mbti': 'ISTP'},
         {'name': '씨잼', 'mbti': 'INTP'}],

        [{'name': '크러쉬', 'mbti': 'INFP'},
         {'name': '키드밀리', 'mbti': 'INTP'},
         {'name': '한요한', 'mbti': 'ENTJ'},
         {'name': '베이식', 'mbti': 'ISFP'}],

        [{'name': '넉살', 'mbti': 'ENFP'},
         {'name': '비오', 'mbti': 'INTJ'},
         {'name': 'DPR 라이브', 'mbti': 'INFJ'},
         {'name': '사이먼 도미닉', 'mbti': 'ESFP'}],

        [{'name': '쿤디판다', 'mbti': 'INTP'},
         {'name': '노스페이스갓', 'mbti': 'INFP'},
         {'name': '기리보이', 'mbti': 'INTP'},
         {'name': '재키와이', 'mbti': 'INTP'}],

        [{'name': '송민호', 'mbti': 'ENFP'},
         {'name': '펀치넬로', 'mbti': 'INFP'},
         {'name': '미노이', 'mbti': 'INTJ'},
         {'name': '코드 쿤스트', 'mbti': 'ENTP'}],

        [{'name': '퀸 와사비', 'mbti': 'ENTP'},
         {'name': '맥대디', 'mbti': 'INTP'},
         {'name': '우원재', 'mbti': 'INFP'},
         {'name': '래원', 'mbti': 'INFP'}],

        [{'name': '블랙넛', 'mbti': 'INFP'},
         {'name': '자이언티', 'mbti': 'ENTP'},
         {'name': '조광일', 'mbti': 'INFP'},
         {'name': '창모', 'mbti': 'INTP'}],

        [{'name': '아이유', 'mbti': 'INFJ'},
         {'name': '이찬혁', 'mbti': 'ENTP'},
         {'name': '던밀스', 'mbti': 'INFJ'},
         {'name': '구스범스', 'mbti': 'INFP'}],

        [{'name': '스윙스', 'mbti': 'ESTP'},
         {'name': '개코', 'mbti': 'ESFP'},
         {'name': '팔로알토', 'mbti': 'ENTJ'},
         {'name': '로스', 'mbti': 'ENFJ'}],

        [{'name': '김심야', 'mbti': 'INTJ'},
         {'name': '언오피셜보이', 'mbti': 'ESTJ'},
         {'name': '애쉬비', 'mbti': 'ISFP'},
         {'name': '릴보이', 'mbti': 'INFP'}],

        [{'name': '최자', 'mbti': 'ENFP'},
         {'name': '해쉬스완', 'mbti': 'INFP'},
         {'name': '릴러말즈', 'mbti': 'ENTP'},
         {'name': '스월비', 'mbti': 'INFJ'}],
    ]

    init_score = previous_score = evaluate_rapper_total_list(rapper_total)
    print('INIT_SCORE', init_score)

    for i in range(GENERATION):

        rapper_total_copied = copy.deepcopy(rapper_total)

        crossover(rapper_total_copied)
        mutation(rapper_total_copied)

        current_score = evaluate_rapper_total_list(rapper_total_copied)
        if current_score > previous_score:
            print('GENERATION {0}: {1}'.format(i, current_score))
            rapper_total = rapper_total_copied
            previous_score = current_score

    final_score = evaluate_rapper_total_list(rapper_total)
    print('FINAL_SCORE', final_score)
    print_total(rapper_total)
